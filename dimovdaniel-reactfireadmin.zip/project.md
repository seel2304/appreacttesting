**FireAdmin**

CRUD of Firebase data

##Create

- Use data from exported json
- On arrays, add new item
- On Fields, add new field


##Read

- Show the items put in array by the id


##Update

##Delete